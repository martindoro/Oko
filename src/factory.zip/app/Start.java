package app;

import handler.CardHandler;
import model.Constants;
import model.card.Card;

public class Start {
	public static void main(String[] args) {
		System.out.println("Štart hry...");
		Player player = new Player();
		Player computer = new Player();
		player.setCards(CardFactory.getInstance().createCard(Constants.DIAMONDS, Constants.EIGHT));
		computer.setCards(CardFactory.getInstance().createCard(Constants.HEARTS, Constants.KING));
		player.setCards(CardFactory.getInstance().createCard(Constants.CLUBS, Constants.TEN));
		computer.setCards(CardFactory.getInstance().createCard(Constants.SPADES, Constants.JACK));
		player.setCards(CardFactory.getInstance().createCard(Constants.SPADES, Constants.QUEEN));
		computer.setCards(CardFactory.getInstance().createCard(Constants.DIAMONDS, Constants.ACE));

		for (Card card : player.getCards()) {
			CardHandler.drawCard(card);
		}
	}
}
