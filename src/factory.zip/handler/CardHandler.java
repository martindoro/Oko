package handler;

import model.Constants;
import model.card.Card;

public class CardHandler {
	public static void drawCard(Card card) {
		char colour = card.getColour();
		String label = card.getLabel();

		System.out.println(drawTopLine());
		System.out.println(drawLabelLine(label));
		System.out.println(drawColourLine(colour));
		for (int i = 0; i < Constants.CARD_SIZE_Y - 6; i++) {
			System.out.println(drawEmptyLine());
		}
		System.out.println(drawColourLine(colour));
		System.out.println(drawLabelLine(label));
		System.out.println(drawBottomLine());
	}

	public static String drawTopLine() {
		StringBuilder line = new StringBuilder();
		line.append(Constants.TLC);
		for (int i = 0; i < Constants.CARD_SIZE_X - 2; i++) {
			line.append(Constants.HLINE);
		}
		line.append(Constants.TRC);
		return line.toString();
	}

	public static String drawBottomLine() {
		StringBuilder line = new StringBuilder();
		line.append(Constants.BLC);
		for (int i = 0; i < Constants.CARD_SIZE_X - 2; i++) {
			line.append(Constants.HLINE);
		}
		line.append(Constants.BRC);
		return line.toString();
	}

	public static String drawLabelLine(String label) {
		StringBuilder line = new StringBuilder();
		line.append(Constants.VLINE);
		line.append(label);
		for (int i = 0; i < Constants.CARD_SIZE_X - 2 - label.length() * 2; i++) {
			line.append(Constants.SPACE);
		}
		line.append(label);
		line.append(Constants.VLINE);
		return line.toString();
	}

	public static String drawColourLine(char colour) {
		StringBuilder line = new StringBuilder();
		line.append(Constants.VLINE);
		line.append(Constants.SPACE);
		line.append(colour);
		for (int i = 0; i < Constants.CARD_SIZE_X - 6; i++) {
			line.append(Constants.SPACE);
		}
		line.append(colour);
		line.append(Constants.SPACE);
		line.append(Constants.VLINE);
		return line.toString();
	}

	public static String drawEmptyLine() {
		StringBuilder line = new StringBuilder();
		line.append(Constants.VLINE);
		for (int i = 0; i < Constants.CARD_SIZE_X - 2; i++) {
			line.append(Constants.SPACE);
		}
		line.append(Constants.VLINE);
		return line.toString();
	}
}
