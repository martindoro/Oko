package model.card;

public enum Value {
	SEVEN(7, model.Constants.SEVEN), EIGHT(8, model.Constants.EIGHT), NINE(9, model.Constants.NINE), TEN(10,
			model.Constants.TEN), JACK(1, model.Constants.JACK), QUEEN(1,
					model.Constants.QUEEN), KING(2, model.Constants.KING), ACE(11, model.Constants.ACE);

	private final int value;
	private final String label;

	Value(int value, String label) {
		this.value = value;
		this.label = label;
	}

	public String getLabel() {
		return this.label;
	}

	public int getValue() {
		return value;
	}
}
