package model.card;

import model.Constants;

public enum Colour {
	SPADES(Constants.SPADES), HEARTS(Constants.HEARTS), DIAMONDS(Constants.DIAMONDS), CLUBS(Constants.CLUBS);

	private final char colour;

	Colour(char colour) {
		this.colour = colour;
	}

	public char getColour() {
		return this.colour;
	}
}
